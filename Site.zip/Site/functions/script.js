let clicked = 0;

const btn = document.getElementById("test");
const send = document.getElementById("send")


        btn.addEventListener("click", function() {
            clicked += 1;
            console.log(clicked)
            if (clicked === 20) {
                confetti({
                    particleCount: 100,
                    spread: 70,
                    origin: { y: 0.6 }
                });
            }
        });

                send.addEventListener("click", function() {
               setTimeout(function() {
                    window.location.href = "sites/formtosend.html"; // Replace with your target URL
                }, 3000); // Delay in milliseconds (3000ms = 3 seconds)

        });


