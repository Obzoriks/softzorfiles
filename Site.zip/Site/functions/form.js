const webhookUrl = 'https://discord.com/api/webhooks/1251251671317610497/1btbrZfRKHlKrBmfyecPSvvJLwDDN-Ozgq3AramH5reopAowWpssTaZbBfuWJ3_5tH2m2';
const ideatext = document.getElementById("valueinput");
const discord = document.getElementById("discord");
const axios = require("axios")
async function sendMessageToDiscord() {
    const payload = {
        content: "Новый запрос идеи от сайта obzoriksx github1",
        embeds: [
            {
                title: "Запрос на идею",
                description: ideatext.value,
                color: 16711680, // Цвет в формате десятичного числа (в данном случае, красный)
                fields: [
                    {
                        name: "Дискорд",
                        value: discord.value
                    },
                    {
                        name: "IP",
                        value: "Не удалось получить IP адрес"
                    }
                ],
                author: {
                    name: "name"
                }
            }
        ],
        attachments: []
    };

axios.post(webhookUrl, payload)
  .then(response => console.log('Успех:', response.data))
  .catch(error => console.error('Ошибка:', error));

}
function handleClick() {
    sendMessageToDiscord();
}
